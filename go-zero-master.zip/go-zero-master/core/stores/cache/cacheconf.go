package cache

// CacheConf is an alias of ClusterConf.
type CacheConf = ClusterConf
